## Scraper

Lambda endpoint for scraping Corona Data

https://observablehq.com/@jptomanelli/nys-covid-19-map

